@extends('layouts.home')

@section('content')
  @include('partials.home.content')
@endsection
