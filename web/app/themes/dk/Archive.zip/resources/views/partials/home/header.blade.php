<div class="preloader">
  <div class="preloader-anim"></div>
</div>
